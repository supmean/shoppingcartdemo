package com.shoppingcartdemo.demo.entity;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ShoppingCartTest {
    private ShoppingCart shoppingCart;
    private Product doveSoap;

    @BeforeEach
    void init() {
        shoppingCart = new ShoppingCart();
        doveSoap = new Product.ProductBuilder()
                .withProductName("Dove Soap")
                .withUnitPrice(39.99).build();
    }

    @Test
    void add() {
        shoppingCart.add(doveSoap);
        Assert.assertNotNull(shoppingCart.getProductIntegerMap().get(doveSoap));
        Assert.assertEquals("39.99", shoppingCart.getTotalPriceRounded().toString());
    }

    @Test
    void testAdd() {
        shoppingCart.add(doveSoap, 5);
        Assert.assertNotNull(shoppingCart.getProductIntegerMap().get(doveSoap));
        Assert.assertEquals("5", shoppingCart.getProductIntegerMap().get(doveSoap).toString());
        Assert.assertEquals("39.99", shoppingCart.round(doveSoap.getUnitPrice()).toString());
        Assert.assertEquals("199.95", shoppingCart.getTotalPriceRounded().toString());
    }

    @Test
    void testConsecutiveAdding(){
        shoppingCart.add(doveSoap, 5);
        Assert.assertNotNull(shoppingCart.getProductIntegerMap().get(doveSoap));
        shoppingCart.add(doveSoap, 3);
        Assert.assertNotNull(shoppingCart.getProductIntegerMap().get(doveSoap));
        Assert.assertEquals("8", shoppingCart.getProductIntegerMap().get(doveSoap).toString());
        Assert.assertEquals("39.99", shoppingCart.round(doveSoap.getUnitPrice()).toString());
        Assert.assertEquals("319.92", shoppingCart.getTotalPriceRounded().toString());

    }
    @Test
    void remove() {
        shoppingCart.add(doveSoap);
        shoppingCart.remove(doveSoap);
        Assert.assertNull(shoppingCart.getProductIntegerMap().get(doveSoap));
        Assert.assertEquals("0.00", shoppingCart.getTotalPriceRounded().toString());
    }

    @Test
    void testRemoveAllExistingProduct() {
        shoppingCart.add(doveSoap, 5);
        Assert.assertNotNull(shoppingCart.getProductIntegerMap().get(doveSoap));
        shoppingCart.remove(doveSoap, 5);
        Assert.assertEquals("0.00", shoppingCart.getTotalPriceRounded().toString());
    }


    @Test
    void testWhenOverRemoveProductThrownIllegalParameterException() {
//        shoppingCart.add(doveSoap, 5);
//        Exception exception = Assert.assertThrows(IllegalArgumentException.class, () -> {
//            shoppingCart.remove(doveSoap, 8);
//        });
//        String expectedMessage = "Removing Product Error";
//        String actualMessage = exception.getMessage();
//
//        Assert.assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    void testRemovePartOfExistingProduct(){
        shoppingCart.add(doveSoap, 5);
        Assert.assertNotNull(shoppingCart.getProductIntegerMap().get(doveSoap));
        shoppingCart.remove(doveSoap, 4);
        Assert.assertEquals("39.99", shoppingCart.getTotalPriceRounded().toString());
    }

    @Test
    void print() {
    }
}