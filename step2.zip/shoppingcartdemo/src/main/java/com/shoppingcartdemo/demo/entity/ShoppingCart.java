package com.shoppingcartdemo.demo.entity;

import lombok.Data;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * @author
 */
@Data
public class ShoppingCart {
    private Map<Product, Integer> productIntegerMap;
    private int itemCount;
    private double totalPrice;
    private BigDecimal totalPriceRounded;
    private int capacity;


    public ShoppingCart() {

        productIntegerMap = new HashMap<Product, Integer>();
    }

    public void add(Product product) {
        add(product, 1);

    }

    public void add(Product product, int n) {
        if (!productIntegerMap.containsKey(product)) {
            productIntegerMap.put(product, n);
        } else {
            int before = productIntegerMap.get(product).intValue();
            int after = before + n;
            productIntegerMap.put(product, after);
        }
        totalPrice += product.getUnitPrice() * n;
        totalPriceRounded = round(totalPrice);
    }

    /**
     * Add single Product
     *
     * @param product
     */
    public void remove(Product product) {
        remove(product, 1);
    }

    /**
     * Add a number of Product at the same time
     *
     * @param product
     * @param n
     */
    public void remove(Product product, int n) {
        int before = productIntegerMap.get(product).intValue();

        if (before == n) {
            productIntegerMap.remove(product);
        } else if (before > n) {
            int after = before - n;
            productIntegerMap.put(product, after);
        } else {
            throw new IllegalArgumentException("Removing Product Error");
        }
        totalPrice -= product.getUnitPrice() * n;
        totalPriceRounded = round(totalPrice);
    }

    /**
     * Utility that calculate rounded number with decimal scale of two
     *
     * @param number
     * @return
     */
    public BigDecimal round(double number) {
        return new BigDecimal(number).setScale(2, RoundingMode.HALF_UP);
    }

    /**
     * Print out the Shopping Cart content
     */
    public void print() {
        StringBuffer sb = new StringBuffer();
        sb.append("The shopping list: \n");

        Set<Product> productKey = productIntegerMap.keySet();
        Iterator<Product> productIterator = productKey.iterator();
        while (productIterator.hasNext()) {
            Product product = productIterator.next();
            Integer unit = productIntegerMap.get(product);
            sb.append(String.format("%d of %s: $%s \n", unit, product.getProductName(), unit * product.getUnitPrice()));
        }
        sb.append(String.format("\t\t\t Total Price: $%s\n", totalPriceRounded));
        System.out.println(sb);
    }

    public static void main(String[] args) {
        ShoppingCart shoppingCart = new ShoppingCart();
        Product doveSoap = new Product.ProductBuilder()
                .withProductName("Dove Soap")
                .withUnitPrice(39.99).build();
        shoppingCart.add(doveSoap,5);
        shoppingCart.remove(doveSoap,2);
        shoppingCart.print();
    }
}
