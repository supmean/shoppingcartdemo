package com.shoppingcartdemo.demo.entity;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class Product {

    private String productName;
    private double unitPrice;

    public static final class ProductBuilder {
        private String productName;
        private double unitPrice;

        ProductBuilder() {
        }

        public static ProductBuilder aProduct() {
            return new ProductBuilder();
        }

        public ProductBuilder withProductName(String productName) {
            this.productName = productName;
            return this;
        }

        public ProductBuilder withUnitPrice(double unitPrice) {
            this.unitPrice = unitPrice;
            return this;
        }

        public Product build() {
            Product product = new Product();
            product.setProductName(productName);
            product.setUnitPrice(unitPrice);
            return product;
        }
    }
}
